const $ = (s) => document.querySelector(s);
const musicBtn = $('#musicBtn');
const bgMusic = $('#bgMusic');
const modal = $('#surpriseModal');
const surpriseBtn = $('#surpriseBtn');
const closeModal = $('#closeModal');
const wishBtn = $('#wishBtn');

// ====== PERSONALISASI CEPAT ======
const CONFIG = {
  name: 'Sayang', // ganti nama pacarmu di sini
  letterName: 'Sayang',
};
$('#birthdayName').textContent = CONFIG.name + '!';
$('#letterName').textContent = CONFIG.letterName;

// Reveal animation
const observer = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if (entry.isIntersecting) entry.target.classList.add('show');
  });
}, { threshold: .12 });
document.querySelectorAll('.reveal').forEach(el => observer.observe(el));

// Music: gunakan assets/birthday-song.mp3 bila tersedia.
// Jika tidak ada, tombol akan memainkan melodi sintetis singkat yang original/cute.
let synthInterval = null;
let audioCtx = null;
let musicPlaying = false;

function beep(freq, start, duration, volume=.04){
  audioCtx ||= new (window.AudioContext || window.webkitAudioContext)();
  const osc = audioCtx.createOscillator();
  const gain = audioCtx.createGain();
  osc.type = 'triangle';
  osc.frequency.value = freq;
  gain.gain.setValueAtTime(0.001, audioCtx.currentTime + start);
  gain.gain.exponentialRampToValueAtTime(volume, audioCtx.currentTime + start + .02);
  gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + start + duration);
  osc.connect(gain).connect(audioCtx.destination);
  osc.start(audioCtx.currentTime + start);
  osc.stop(audioCtx.currentTime + start + duration + .04);
}
function synthLoop(){
  // original cheerful loop, not a copy of a Chiikawa track
  const notes = [659,784,880,784,659,523,587,659,784,659,587,523];
  notes.forEach((n,i)=>beep(n,i*.18,.15,.035));
}
async function toggleMusic(){
  if (musicPlaying){
    bgMusic.pause();
    clearInterval(synthInterval); synthInterval=null;
    musicPlaying=false; musicBtn.classList.remove('playing'); musicBtn.textContent='♫';
    return;
  }
  try{
    await bgMusic.play();
  }catch(e){
    synthLoop();
    synthInterval=setInterval(synthLoop, 2600);
  }
  musicPlaying=true; musicBtn.classList.add('playing'); musicBtn.textContent='❚❚';
}
musicBtn.addEventListener('click', toggleMusic);

// Modal surprise
surpriseBtn.addEventListener('click', ()=>{
  modal.classList.add('show'); modal.setAttribute('aria-hidden','false'); burst(120);
});
closeModal.addEventListener('click', ()=>{modal.classList.remove('show');modal.setAttribute('aria-hidden','true')});
modal.addEventListener('click', e=>{if(e.target===modal) closeModal.click()});
wishBtn.addEventListener('click', ()=>{burst(220);wishBtn.textContent='Wish locked in! 💛';});
$('#confettiBtn').addEventListener('click', ()=>burst(180));

// Confetti canvas
const canvas = $('#confetti');
const ctx = canvas.getContext('2d');
let pieces=[];
function resize(){canvas.width=innerWidth*devicePixelRatio;canvas.height=innerHeight*devicePixelRatio;ctx.setTransform(devicePixelRatio,0,0,devicePixelRatio,0,0)}
addEventListener('resize',resize);resize();
function burst(count=100){
  for(let i=0;i<count;i++) pieces.push({
    x:innerWidth/2+(Math.random()-.5)*180,y:innerHeight*.42,
    vx:(Math.random()-.5)*9,vy:-Math.random()*9-4,g:.18+Math.random()*.08,
    r:3+Math.random()*5,rot:Math.random()*6,vr:(Math.random()-.5)*.25,
    c:['#ffd84d','#ff8ca4','#ffffff','#71c9ff','#8bd17c'][Math.floor(Math.random()*5)],life:140+Math.random()*40
  });
}
function tick(){
  ctx.clearRect(0,0,innerWidth,innerHeight);
  pieces.forEach(p=>{p.x+=p.vx;p.y+=p.vy;p.vy+=p.g;p.rot+=p.vr;p.life--;ctx.save();ctx.translate(p.x,p.y);ctx.rotate(p.rot);ctx.fillStyle=p.c;ctx.fillRect(-p.r,-p.r/2,p.r*2,p.r);ctx.restore()});
  pieces=pieces.filter(p=>p.life>0&&p.y<innerHeight+30);
  requestAnimationFrame(tick);
}
tick();
setTimeout(()=>burst(90),700);
